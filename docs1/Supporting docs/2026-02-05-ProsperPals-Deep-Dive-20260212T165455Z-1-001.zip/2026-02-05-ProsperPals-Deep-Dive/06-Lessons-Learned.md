# ProsperPals - Lessons Learned from Previous Attempts
**Date:** 2026-02-05  
**Source:** Building Notes, Fresh Start doc, Environment install notes

---

## 🚨 Critical Failures to Avoid

### 1. Don't Let Claude Code Improvise the UI
**What Happened:** Previous builds failed because AI coding tools created UI without design reference, resulting in inconsistent, unapproved designs.

**Solution:** Design First!
1. Relume → Figma → THEN code
2. Give AI tools a design reference to match
3. Never start coding without approved mockups

---

### 2. Lovable/v0 Doesn't Sync to GitHub Properly
**What Happened:** Projects built in Lovable/v0 had sync issues, causing version control problems and lost work.

**Solution:** 
- ❌ NO Lovable/v0
- ✅ Use Codex for architecture
- ✅ Use Cursor + Claude Code for UI
- ✅ Git from day 1

---

### 3. Supabase RLS Can Cause Insert Timeouts
**Issue Reference:** ISSUE-001 documented in PRD

**What Happens:** Row Level Security (RLS) policies deny access to unauthenticated or improperly authenticated requests, causing timeouts.

**Solution:**
- Enable RLS from Day 1 (don't bolt on later)
- Every database operation must use authenticated user context
- Test RLS policies before building features
- `auth.uid() = user_id` clause on every user-specific table

---

### 4. n8n Workflow Output is Complex JSON
**What Happened:** AI agent output is not just text - it's complex JSON with intents, entities, and metadata. Simple text streaming broke the UI.

**Solution:**
- Design structured API contract between AI and frontend
- Response includes: `type`, `content`, `component`, `props`
- Frontend becomes a renderer for AI commands

```typescript
// Example API Response Contract
interface AIResponse {
  type: 'text' | 'component';
  content?: string;  // If type is 'text'
  component?: string; // e.g., 'CoinAward', 'GoalProgress'
  props?: object;     // Props to pass to component
}
```

---

### 5. Environment Setup is Critical
**What Happened:** Missing environment variables, wrong API keys, and inconsistent configs caused days of debugging.

**Solution:** Maintain a comprehensive env checklist:

| Variable | Description | Source |
|----------|-------------|--------|
| NEXT_PUBLIC_SUPABASE_URL | Supabase API URL | Supabase Settings |
| NEXT_PUBLIC_SUPABASE_ANON_KEY | Public anon key | Supabase Settings |
| SUPABASE_SERVICE_ROLE_KEY | Server-side key | Supabase Settings |
| OPENAI_API_KEY | OpenAI access | OpenAI Dashboard |
| ELEVENLABS_API_KEY | Voice synthesis | ElevenLabs Dashboard |
| N8N_WEBHOOK_URL | Workflow trigger | n8n Editor |
| WEBHOOK_SECRET | Verify payloads | Generate yourself |

---

## 📊 What Worked Well

### 1. Hybrid Conversational-Navigational Model
The concept of chat-first with visual dashboards on-demand was validated as strong UX.

### 2. Gamification Concept
User testing showed high engagement with Keys system and ProsperCoins.

### 3. AI Companions Concept
Goldie and Fin personas tested well - users liked having distinct personalities.

### 4. Off-Chain Coins for MVP
Keeping ProsperCoins as database points for MVP removes blockchain complexity.

---

## 🔧 Technical Decisions Validated

### Stay with Supabase ✅
- Already set up
- PostgreSQL more flexible
- No vendor lock-in
- Real-time subscriptions work well
- Auth built-in

### Vercel AI SDK ✅
- Native TypeScript
- Provider-agnostic
- Good documentation
- Active development

### Next.js 14 ✅
- App Router is mature
- Server components work well
- Good Vercel integration

---

## ⚠️ Architecture Changes from Old Docs

### OLD Architecture (Pre-Agent)
```
User → Form → Database → Display
```

### NEW Architecture (AI-First)
```
User → Chat → AI Agent → Function Calls → Database → AI Response → Display
```

Key difference: **AI is the primary interface**, not forms.

---

## 🗃️ Database Schema Lessons

### Keep These Tables
- `user_stats` (coins, level, XP)
- `financial_accounts`
- `financial_goals`
- `transactions`
- `budgets`
- `user_achievements`
- `virtual_portfolios`
- `virtual_holdings`

### Add These Tables (Not in Old Schema)
- `ai_conversation_history` (for context)
- `user_preferences` (voice, language, AI personality settings)
- `interaction_logs` (for the data flywheel)

---

## 🎯 MVP Scope Recommendations

### Include in MVP ✅
- Basic chat with Goldie
- Manual account entry + balances
- Simple budget tracking
- ProsperCoins (off-chain)
- 10-15 achievements
- Basic investment simulator
- One learning path (Budgeting Basics)

### Defer to Phase 2 ⏰
- Fin (investment educator)
- Blockchain ProsperCoins
- NFT badges
- Bank API integration (Plaid)
- Voice interaction (ElevenLabs)
- Full Keys system
- Community features
- Mobile app

---

## 📝 Development Process Recommendations

### Week 1: Design
- Relume wireframes
- Figma high-fidelity
- Get sign-off before ANY code

### Week 2: Specs
- BMAD PRD
- Architecture doc
- Database schema
- TaskMaster task list

### Week 3-4: Foundation
- Next.js project setup
- Supabase schema
- Auth flow
- Basic chat UI

### Week 5-6: Core Features
- Goldie agent
- Transaction logging
- Budget tracking
- ProsperCoins earning

### Week 7-8: Polish
- Investment simulator
- Achievements
- Testing
- Deploy

---

## 🔑 Key Takeaways

1. **Design First** - No exceptions
2. **AI-First Architecture** - Chat is the main UI
3. **Start Simple** - Off-chain, manual entry, basic features
4. **Log Everything** - Build the data flywheel
5. **Test RLS Early** - Don't wait until production
6. **Structured AI Responses** - Not just text streams
7. **Environment Discipline** - Document all variables

---

*"Every failure is a lesson. The previous attempts weren't wasted - they're the roadmap for what works."*
