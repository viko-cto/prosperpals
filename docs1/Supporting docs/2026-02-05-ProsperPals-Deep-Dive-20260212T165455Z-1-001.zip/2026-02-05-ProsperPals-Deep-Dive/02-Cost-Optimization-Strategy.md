# ProsperPals - Cost Optimization Strategy
**Date:** 2026-02-05  
**Source:** LiteLLM docs, Intelligent Gateway strategy doc

---

## 🎯 The Three-Pillar Approach

### Pillar 1: Abstraction Layer (Vercel AI SDK)
- Standardizes code across all model providers
- Change providers with 2 lines of code
- No vendor lock-in at the CODE level

### Pillar 2: Intelligent Gateway (Vercel AI Gateway or OpenRouter)
- Single endpoint for hundreds of models
- Centralized cost management
- Built-in caching, fallbacks, analytics

### Pillar 3: Model Cascading
- Route requests based on task complexity
- Simple tasks → cheap/free models
- Complex tasks → premium models

---

## 💰 Model Cascading Strategy

| Task Type | Model | Cost | Use Case |
|-----------|-------|------|----------|
| **Simple** | DeepSeek Free, Mistral Small | FREE | Summarization, classification, basic Q&A |
| **Standard** | GPT-4o-mini, Claude Haiku | $0.15-0.80/M | Transaction logging, budget advice, lessons |
| **Complex** | Claude Opus, GPT-4o | $15/M | Investment analysis, complex reasoning |

### Example Implementation
```typescript
// lib/ai/config.ts
import { google } from '@ai-sdk/google';
import { anthropic } from '@ai-sdk/anthropic';

export const models = {
  // Fast & Cheap: Transaction parsing, suggestions
  fast: google('gemini-2.0-flash-exp'),  // $0.10/M
  
  // Standard: Conversations, Goldie/Fin dialogue
  standard: anthropic('claude-3-5-haiku-20241022'),  // $0.80/M
  
  // Complex: Investment explanations, market analysis
  complex: anthropic('claude-3-5-sonnet-20241022'),  // $3/M
};
```

---

## 📊 Projected Costs

### MVP Phase (1K users, 10 actions/day)
| Model Tier | Requests/day | Cost/request | Monthly Cost |
|------------|--------------|--------------|--------------|
| Fast (60%) | 6,000 | ~$0.0001 | $18 |
| Standard (35%) | 3,500 | ~$0.001 | $105 |
| Complex (5%) | 500 | ~$0.01 | $150 |
| **Total** | 10,000 | - | **~$273/mo** |

### Scale Phase (10K users)
- Estimated: **~$2,700/mo** with current cascade
- Can reduce to ~$500/mo with aggressive free-tier usage

---

## 🔄 The Data Flywheel

**Critical for Long-term Moat**: Log EVERYTHING from Day 1!

### What to Log
1. User's full prompt
2. Which model was selected
3. Model's full response
4. User feedback (accepted, edited, retried?)
5. Task type and context

### Why This Matters
- This becomes your "golden dataset"
- Future fine-tuning uses this data
- Can train custom model specifically for financial conversations
- Reduces dependency on expensive APIs over time

---

## ⚠️ Migration Trap Warning

### What Vercel AI SDK SOLVES ✅
- Code-level vendor lock-in
- API format differences
- Easy provider switching in code

### What It Does NOT Solve ❌
- **Prompt Brittleness**: Prompts optimized for GPT-4 may fail on Claude
- **Behavioral Differences**: Models have different strengths
- **Feature Parity**: Not all providers support all features equally

### Mitigation Strategy
1. Design prompts to be model-agnostic where possible
2. Test prompts across multiple models during development
3. Keep prompt templates in a central location
4. Document model-specific quirks

---

## 🛠️ Implementation Roadmap

### Phase 1: MVP (Now)
- Use Vercel AI SDK with Vercel AI Gateway
- Implement basic model cascade (2-3 tiers)
- Start logging all interactions

### Phase 2: Post-Funding (6 months)
- Analyze logged data
- Identify highest-volume tasks
- Consider self-hosting for that ONE task (~$550/mo on RunPod)

### Phase 3: Scale
- Fine-tune open-source model on your data
- Gradually migrate from APIs
- Keep premium API for edge cases

---

## 🔑 Key Takeaways

1. **Start with APIs** - They're actually cost-effective at low volume
2. **Implement cascading from Day 1** - Most requests should hit cheap models
3. **Log everything** - Your data is your moat
4. **Don't over-engineer** - ~$300/mo for 1K users is fine for MVP
5. **Plan for migration, don't execute it yet** - Wait for real data

---

*"The best AI strategy for a bootstrapped startup: use the best APIs now, build the infrastructure to leave them later."*
