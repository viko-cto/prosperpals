# ProsperPals - Regulatory & Compliance Guide
**Date:** 2026-02-05  
**Critical Reading for MVP Development**

---

## 🎯 Core Positioning

### Financial WELLNESS, Not Financial ADVICE

This distinction is **CRITICAL** and must be maintained throughout:

| Financial Advice (AVOID) | Financial Wellness (SAFE) |
|--------------------------|---------------------------|
| "Buy AAPL stock now" | "Here's how stock investing works" |
| "Put 70% in crypto" | "Let's explore different asset classes" |
| "Refinance your mortgage with X bank" | "Here are factors to consider when refinancing" |
| "Your portfolio is wrong" | "Let's learn about diversification" |

---

## ⚠️ What AI Companions Should NEVER Do

### Goldie & Fin MUST NOT:
1. ❌ Recommend specific stocks, bonds, or securities
2. ❌ Suggest cryptocurrency investments ("Buy Bitcoin now!")
3. ❌ Provide personalized portfolio allocation advice
4. ❌ Make predictions about market movements
5. ❌ Recommend specific financial products (loans, credit cards)
6. ❌ Claim to guarantee returns or outcomes
7. ❌ Access or transmit real trading orders

### They CAN:
1. ✅ Explain financial concepts educationally
2. ✅ Help track spending and budgeting
3. ✅ Celebrate savings milestones
4. ✅ Provide general financial literacy content
5. ✅ Facilitate SIMULATED trading practice
6. ✅ Connect users to licensed advisors (with disclaimers)

---

## 📜 Required Disclaimers

### App-Wide Disclaimers
```
"ProsperPals is an educational platform for financial literacy. 
The information provided is for general educational purposes only 
and should not be considered financial, investment, tax, or legal advice. 
Past performance in simulations does not guarantee real-world results.
Consult a licensed financial advisor for personalized advice."
```

### AI Conversation Disclaimers
```
"I'm your AI learning companion, not a licensed financial advisor. 
My suggestions are for educational exploration only."
```

### Investment Simulator Disclaimers
```
"This is a simulation using historical data and virtual currency.
Real market results may differ significantly.
Do not make real investment decisions based on simulated outcomes."
```

---

## 🌐 Web3/Blockchain Considerations

### ProsperCoins - Regulatory Positioning

**MVP Approach: Off-Chain Points**
- Treated as loyalty rewards (like airline miles)
- No real-money value
- Cannot be exchanged, sold, or transferred
- Database entries, not blockchain tokens

**Phase 2: On-Chain Tokens**
- Utility tokens for in-app features ONLY
- No secondary market (soulbound or heavily restricted)
- Clear terms that they have no monetary value
- Consult crypto-regulatory counsel before launch

### NFT Badges - Soulbound Tokens

**Why Soulbound is SAFER:**
- Cannot be sold = not a security
- No speculative value = less regulatory scrutiny
- Achievement recognition only
- Similar to digital certificates

**Required Terms:**
```
"NFT Achievement Badges are non-transferable digital certificates 
of completion. They have no monetary value and cannot be sold, 
traded, or transferred. They exist solely as proof of achievement 
within the ProsperPals ecosystem."
```

---

## 🔒 Security & Privacy

### GDPR Compliance (EU Users)
- Right to access data
- Right to deletion
- Right to portability
- Explicit consent for data processing
- Data minimization
- Clear privacy policy

### CCPA Compliance (California Users)
- Disclosure of data collection
- Right to opt-out of sales
- Right to delete personal info
- Non-discrimination for exercising rights

### Financial Data Security
- **AES-256 encryption** for sensitive data
- **Bank-grade authentication** (MFA required)
- **No storage of banking credentials** (use Plaid/Tink)
- **Regular security audits** (SOC 2 certification planned)
- **Audit trail** for all account modifications

---

## 📊 Data Handling Rules

### What We CAN Collect
- Email, username, password (hashed)
- Self-reported account balances
- Transaction categories (not raw bank data initially)
- Learning progress
- Achievement data
- Usage analytics (anonymized)

### What We Should NOT Store
- Full bank account numbers
- Social security numbers
- Credit card numbers
- Raw banking credentials
- Biometric data (without explicit consent)

### Data Retention
- Active accounts: Retain as needed
- Deleted accounts: Purge within 30 days
- Analytics: Anonymize after 90 days
- Financial data: User controls deletion

---

## 👶 Age Restrictions

### Minimum Age Requirements
| Region | Minimum Age |
|--------|-------------|
| US | 13 (COPPA) |
| EU | 16 (GDPR) |
| UK | 13 |

### For Users 13-17
- Parental consent required
- Limited features (no simulated trading with adult content)
- No blockchain features
- Educational content only
- Parental dashboard access

---

## 🛡️ Anti-Fraud & Anti-Gaming

### ProsperCoin Protections
- Daily earning caps (500 coins/day)
- Transaction verification required
- Duplicate detection
- Suspicious activity monitoring
- Account suspension for exploitation

### Community Safety
- AI-powered content filtering
- Human review for edge cases
- Community reporting system
- Strike system for violations
- Appeal process

---

## 📋 Pre-Launch Checklist

### Legal Documents Needed
- [ ] Terms of Service
- [ ] Privacy Policy
- [ ] Cookie Policy
- [ ] Investment Simulator Disclaimer
- [ ] AI Assistant Disclaimer
- [ ] Community Guidelines
- [ ] NFT/Token Terms (Phase 2)

### Technical Implementations
- [ ] Age verification gate
- [ ] Consent management platform
- [ ] Data export functionality
- [ ] Account deletion flow
- [ ] Disclaimer display before key features
- [ ] Audit logging system

### Reviews Required
- [ ] Legal review of all disclaimers
- [ ] Fintech regulatory consultation
- [ ] GDPR compliance audit
- [ ] Security penetration testing
- [ ] Crypto-regulatory review (before Phase 2)

---

## 🚨 Red Flags to Avoid

1. **Never** market ProsperCoins as having real value
2. **Never** promise financial returns
3. **Never** let AI give specific investment recommendations
4. **Never** store sensitive banking credentials
5. **Never** allow minors without parental consent
6. **Never** share user data without explicit consent
7. **Never** use dark patterns to trick users

---

*"The safest fintech is one that empowers users to learn without putting them at risk."*
