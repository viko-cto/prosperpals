# BMAD Method & Agentic Workflows
**Date:** 2026-02-05  
**Source:** Skills folder, Building Notes

---

## 🎯 What is BMAD?

BMAD (Business-Model-Architecture-Development) is a methodology for using AI agents in specialized roles to build comprehensive specifications before coding.

### The Key Insight
"Instead of filling out forms, the agents ask questions, and based on the replies, create documents that can fill out the forms for the users instead of manual data entry."

---

## 👥 BMAD Agent Roles

### 1. Product Owner (Mary)
**Purpose:** Define vision, requirements, user stories

**Questions Mary Asks:**
- What problem are we solving?
- Who are the users?
- What are the core features?
- What's the success criteria?

**Output Documents:**
- Project Brief
- Product Requirements Document (PRD)
- User Personas
- User Journeys

---

### 2. System Architect
**Purpose:** Technical design and infrastructure

**Questions Architect Asks:**
- What's the expected scale?
- What integrations are needed?
- What are the security requirements?
- What's the data model?

**Output Documents:**
- System Architecture Document
- Database Schema
- API Design
- Agent Specifications
- Security & Auth Design

---

### 3. Scrum Master
**Purpose:** Break work into manageable pieces

**Questions Scrum Master Asks:**
- What are the major features (Epics)?
- What user stories make up each epic?
- What's the acceptance criteria?
- How complex is each story?

**Output Documents:**
- Epics list
- User Stories with acceptance criteria
- Story point estimates
- Sprint planning suggestions

---

## 🔄 The Complete Workflow

```
┌─────────────────────────────────────────────────────────────────────┐
│                    SPECIFICATION WORKFLOW                           │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  PHASE 1: VISION & PRD (BMAD - Product Owner)                       │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │ • Project Brief (problem, solution, users)                   │    │
│  │ • Product Requirements Document                              │    │
│  │ • User Personas                                              │    │
│  │ • User Journeys                                              │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                              ↓                                       │
│  PHASE 2: ARCHITECTURE (BMAD - System Architect)                    │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │ • System Architecture Document                               │    │
│  │ • Database Schema                                            │    │
│  │ • API Design                                                 │    │
│  │ • Agent Specifications                                       │    │
│  │ • Security & Auth Design                                     │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                              ↓                                       │
│  PHASE 3: BREAKDOWN (BMAD - Scrum Master)                           │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │ • Epics (major features)                                     │    │
│  │ • User Stories with acceptance criteria                      │    │
│  │ • Story point estimates                                      │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                              ↓                                       │
│  PHASE 4: TASK MANAGEMENT (TaskMaster)                              │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │ • Convert stories to tasks                                   │    │
│  │ • Define dependencies                                        │    │
│  │ • Set priorities                                             │    │
│  │ • Track progress                                             │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                      │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 📋 Documents to Create

| Document | Purpose | Tool |
|----------|---------|------|
| Project Brief | Vision, problem, solution | Claude (BMAD PO) |
| PRD | Features, requirements | Claude (BMAD PO) |
| User Personas | Who uses the product | Claude |
| User Journeys | How they use it | Figma/Miro |
| Architecture Doc | Technical design | Claude (BMAD Architect) |
| Database Schema | Tables, relationships | dbdiagram.io + SQL |
| Agent Specs | Each agent's config | Markdown |
| API Design | Endpoints, contracts | OpenAPI/Markdown |
| Epics & Stories | Work breakdown | Markdown/Notion |
| Task List | Development sequence | TaskMaster JSON |

---

## 🎯 Applying to ProsperPals

### The 5 AI Agents Needed

Based on the Fresh Start doc, ProsperPals needs these agents:

1. **Goldie** - Daily finance motivator
2. **Fin** - Investment educator
3. **Budget Agent** - Tracks spending, categorizes transactions
4. **Goals Agent** - Monitors progress toward financial goals
5. **Simulator Agent** - Manages virtual portfolio

### Agent Specification Template
```markdown
# Agent: [Name]

## Purpose
What this agent does

## Personality
- Tone
- Communication style
- Key phrases

## Capabilities
- What it CAN do
- What it CAN'T do

## Data Access
- What data it reads
- What data it writes

## Triggers
- When it activates
- What prompts it responds to

## Fallbacks
- When to escalate to human
- Error handling
```

---

## 🚀 Recommended Sequence for ProsperPals

### Week 1: DESIGN
- Days 1-2: Relume sitemap & wireframes
- Days 3-5: Figma high-fidelity designs
- Deliverable: Complete UI reference

### Week 2: SPECIFICATIONS
- Day 1: PRD (BMAD Product Owner)
- Day 2: Architecture doc (BMAD Architect)
- Day 3: Database schema
- Days 4-5: Epics, stories, TaskMaster tasks
- Deliverable: Complete development blueprint

### Weeks 3-6: MVP BUILD
- Foundation (Supabase, Auth, AI SDK)
- Chat Interface
- Goldie Agent (basic conversations)
- Budget tracking
- Investment simulator (basic)

### Weeks 7+: Iterate
- Add Fin agent
- Gamification (ProsperCoins)
- Keys system
- Community features

---

## ⚡ Quick Win: Interactive Agent Workflows

One of the coolest applications mentioned in the docs:

**Instead of forms, use conversational agents:**

❌ Old Way:
```
[Name: ________]
[Email: ________]
[Budget: ________]
[Goal: ________]
```

✅ New Way (BMAD-style):
```
Goldie: "Hey! I'm Goldie, your new money bestie! 🌟 
        What should I call you?"

User: "I'm Sarah"

Goldie: "Nice to meet you, Sarah! So tell me - 
        what's the #1 thing you want to achieve with money 
        in the next year?"

User: "Save for a vacation to Japan"

Goldie: "Ooh, Japan! 🇯🇵 Amazing choice! 
        Let's figure out how to make that happen. 
        What's your monthly take-home pay, roughly?"
```

**The AI extracts structured data from natural conversation, then populates the database.**

---

## 🔧 Tools from Skills Folder

### SuperClaude Framework
- Multiple specialized personas
- Session management
- Root cause analysis
- DevOps architecture patterns

### Context7 MCP
- Intelligent documentation search
- Any library documentation

### TaskMaster
- AI-driven task management
- Dependency tracking
- Sprint planning

### Claude-Flow
- AI orchestration platform
- Multi-agent coordination

---

*"The best UI is no UI - just a conversation that gets things done."*
